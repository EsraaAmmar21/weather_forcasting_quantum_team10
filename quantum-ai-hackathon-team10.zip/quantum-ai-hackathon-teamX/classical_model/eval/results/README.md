This folder contains results data.
