This folder contains train data.
